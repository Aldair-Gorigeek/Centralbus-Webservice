package com.gorigeek.springboot.distribution.entity;

public class ReservationsCancelRequest {
	private String reservationId;

	public String getReservationId() {
		return reservationId;
	}

	public void setReservationId(String reservationId) {
		this.reservationId = reservationId;
	}
	
}
