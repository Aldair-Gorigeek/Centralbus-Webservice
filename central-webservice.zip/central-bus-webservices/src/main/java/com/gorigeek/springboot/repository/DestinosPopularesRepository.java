package com.gorigeek.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gorigeek.springboot.entity.DestinosPopulares;

public interface DestinosPopularesRepository extends JpaRepository<DestinosPopulares, Long>{

}
